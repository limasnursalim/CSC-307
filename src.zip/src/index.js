import React, {Component} from 'react'
import ReactDOM from 'react-dom'
import MyApp from './MyApp'
import './index.css'

ReactDOM.render(<MyApp />, document.getElementById('root'))
